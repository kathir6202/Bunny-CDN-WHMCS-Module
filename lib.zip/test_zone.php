<?php
$whmcsRoot = '/home/develpseekahost/public_html/';
require_once $whmcsRoot . 'init.php';

use WHMCS\Database\Capsule;

$serverData = Capsule::table('tblservers')->where('type', 'seekahostcdn')->first();
$apiKey = $serverData->accesshash ?? '';

echo "Testing zone IDs...\n\n";

// Test the original Pull Zone ID
$zoneId1 = '5820528';
echo "Test 1: Pull Zone ID = {$zoneId1}\n";
$ch = curl_init('https://api.bunny.net/pullzone/' . $zoneId1);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['AccessKey: ' . $apiKey, 'Accept: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "HTTP Code: {$httpCode}\n";
$data = json_decode($response, true);
if (is_array($data)) {
    echo "MonthlyBandwidthUsed: " . ($data['MonthlyBandwidthUsed'] ?? 'N/A') . "\n";
    echo "Name: " . ($data['Name'] ?? 'N/A') . "\n";
} else {
    echo "Response: " . substr($response, 0, 200) . "\n";
}
echo "\n";

// Test the UUID zone ID
$zoneId2 = '8bd71665-3';
echo "Test 2: Zone ID = {$zoneId2}\n";
$ch = curl_init('https://api.bunny.net/pullzone/' . $zoneId2);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['AccessKey: ' . $apiKey, 'Accept: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "HTTP Code: {$httpCode}\n";
$data = json_decode($response, true);
if (is_array($data)) {
    echo "Keys: " . implode(', ', array_keys($data)) . "\n";
    echo "MonthlyBandwidthUsed: " . ($data['MonthlyBandwidthUsed'] ?? 'N/A') . "\n";
} else {
    echo "Response: " . substr($response, 0, 200) . "\n";
}
echo "\n";

// Get the DNS zone ID for service 1562
$dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')->where('service_id', 1562)->first();
$dnsZoneId = $dnsInfo->dns_zone_id ?? '789727';

echo "DNS Zone ID: {$dnsZoneId}\n\n";

// Get all DNS records
echo "=== DNS Records ===\n";
$ch = curl_init('https://api.bunny.net/dnszone/' . $dnsZoneId . '/records');
curl_setopt($ch, CURLOPT_HTTPHEADER, ['AccessKey: ' . $apiKey, 'Accept: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: {$httpCode}\n";
$records = json_decode($response, true);

if (is_array($records)) {
    if (count($records) > 0) {
        foreach ($records as $record) {
            if (!is_array($record)) {
                echo "Record is not an array: " . print_r($record, true) . "\n";
                continue;
            }
            $accelerated = isset($record['Accelerated']) && $record['Accelerated'] ? 'YES' : 'NO';
            echo "ID: " . ($record['Id'] ?? 'N/A') . " | ";
            echo "Type: " . ($record['Type'] ?? 'N/A') . " | ";
            echo "Name: " . ($record['Name'] ?? 'N/A') . " | ";
            echo "Value: " . ($record['Value'] ?? 'N/A') . " | ";
            echo "Accelerated: {$accelerated}\n";
            
            // Show all keys
            echo "  Keys: " . implode(', ', array_keys($record)) . "\n";
            
            // Check for linked Pull Zone ID
            if (isset($record['PullZoneId'])) {
                echo "  -> PullZoneId: {$record['PullZoneId']}\n";
            }
            if (isset($record['LinkedPullZoneId'])) {
                echo "  -> LinkedPullZoneId: {$record['LinkedPullZoneId']}\n";
            }
            echo "\n";
        }
    } else {
        echo "No records found.\n";
    }
} else {
    echo "Response is not an array.\n";
    echo "Raw response: " . substr($response, 0, 500) . "\n";
}