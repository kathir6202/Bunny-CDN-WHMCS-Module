<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

// TEMPORARY DEBUG - Remove after fixing
file_put_contents(__DIR__ . '/debug.log', date('Y-m-d H:i:s') . " - Module loaded\n", FILE_APPEND);

use WHMCS\Database\Capsule;

function seekahostcdn_MetaData()
{
    return array(
        'DisplayName' => 'SeekaHost CDN',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
    );
}

function seekahostcdn_ConfigOptions()
{
    return array(
        'origin_url' => array(
            'FriendlyName' => 'Default Origin URL',
            'Type' => 'text',
            'Size' => '40',
            'Description' => 'Default origin server URL (e.g., http://server-ip)',
        ),
    );
}

function seekahostcdn_CreateAccount($params)
{
    try {
        require_once __DIR__ . '/lib/BunnyCDN.php';
        
        // DEBUG LOGGING
        $debugLog = __DIR__ . '/create_debug.log';
        file_put_contents($debugLog, "\n=== " . date('Y-m-d H:i:s') . " ===\n", FILE_APPEND);
        file_put_contents($debugLog, "API Key from params: '" . $params['serveraccesshash'] . "'\n", FILE_APPEND);
        file_put_contents($debugLog, "API Key length: " . strlen($params['serveraccesshash']) . "\n", FILE_APPEND);
        file_put_contents($debugLog, "Domain: " . $params['domain'] . "\n", FILE_APPEND);
        
        $apiKey = trim($params['serveraccesshash']);
        $domain = $params['domain'];
        
        // Build proper origin URL with validation
        if (!empty($params['configoption1'])) {
            $originUrl = $params['configoption1'];
            file_put_contents($debugLog, "Config Option 1 (origin_url) IS SET: '" . $originUrl . "'\n", FILE_APPEND);
        } else {
            $originUrl = 'http://' . $domain;
            file_put_contents($debugLog, "Config Option 1 (origin_url) NOT SET, using default: '" . $originUrl . "'\n", FILE_APPEND);
        }
        
        // Ensure URL has http:// or https:// protocol
        if (!preg_match('/^https?:\/\//', $originUrl)) {
            $oldUrl = $originUrl;
            $originUrl = 'http://' . $originUrl;
            file_put_contents($debugLog, "Added protocol to URL: '" . $oldUrl . "' -> '" . $originUrl . "'\n", FILE_APPEND);
        }
        
        file_put_contents($debugLog, "Final Origin URL being sent to Bunny: '" . $originUrl . "'\n", FILE_APPEND);
        file_put_contents($debugLog, "Using API Key (trimmed): '" . substr($apiKey, 0, 10) . "...'\n", FILE_APPEND);
        
        $bunny = new BunnyCDN_API($apiKey);
        
        // Step 1: Create DNS Zone
        file_put_contents($debugLog, "Creating DNS Zone for: {$domain}\n", FILE_APPEND);
        $dnsResult = $bunny->createDNSZone($domain);
        
        if (!$dnsResult['success']) {
            file_put_contents($debugLog, "DNS Zone FAILED: " . $dnsResult['error'] . "\n", FILE_APPEND);
            return 'DNS Zone creation failed: ' . $dnsResult['error'];
        }
        
        file_put_contents($debugLog, "DNS Zone CREATED: ID=" . $dnsResult['zone_id'] . "\n", FILE_APPEND);
        
        // Step 2: Create Pull Zone
        $zoneName = 'client-' . $params['serviceid'] . '-' . preg_replace('/[^a-z0-9]/', '', $domain);
        file_put_contents($debugLog, "Creating Pull Zone: Name='{$zoneName}', Origin='{$originUrl}'\n", FILE_APPEND);
        
        $pullResult = $bunny->createPullZone($zoneName, $originUrl);
        
        if (!$pullResult['success']) {
            file_put_contents($debugLog, "Pull Zone FAILED: " . $pullResult['error'] . "\n", FILE_APPEND);
            // Clean up the DNS zone we just created
            file_put_contents($debugLog, "Rolling back: Deleting DNS Zone ID=" . $dnsResult['zone_id'] . "\n", FILE_APPEND);
            $bunny->deleteDNSZone($dnsResult['zone_id']);
            return 'Pull Zone creation failed: ' . $pullResult['error'];
        }
        
        file_put_contents($debugLog, "Pull Zone CREATED: ID=" . $pullResult['zone_id'] . ", CDN URL=" . $pullResult['cdn_url'] . "\n", FILE_APPEND);
        
        // Step 3: Link DNS to Pull Zone
        file_put_contents($debugLog, "Linking DNS Zone {$dnsResult['zone_id']} to Pull Zone {$pullResult['zone_id']}\n", FILE_APPEND);
        $linkResult = $bunny->linkDNSToPullZone($dnsResult['zone_id'], $pullResult['zone_id']);
        file_put_contents($debugLog, "Link result: " . ($linkResult['success'] ? 'SUCCESS' : 'FAILED - ' . $linkResult['error']) . "\n", FILE_APPEND);
        
        // Step 4: Save to database
        Capsule::table('tblhosting')
            ->where('id', $params['serviceid'])
            ->update(['dedicatedip' => $pullResult['zone_id']]);
        
        Capsule::table('mod_seekahostcdn_dns_zones')->insert([
            'service_id' => $params['serviceid'],
            'dns_zone_id' => $dnsResult['zone_id'],
            'pull_zone_id' => $pullResult['zone_id'],
            'domain' => $domain,
            'nameserver_1' => $dnsResult['nameservers'][0] ?? 'ns1.bunny.net',
            'nameserver_2' => $dnsResult['nameservers'][1] ?? 'ns2.bunny.net',
            'cdn_url' => $pullResult['cdn_url'],
            'origin_url' => $originUrl,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        Capsule::table('mod_seekahostcdn_zone_config')->insert([
            'service_id' => $params['serviceid'],
            'zone_id' => $pullResult['zone_id'],
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        file_put_contents($debugLog, "=== SUCCESS: Zone fully created and saved ===\n", FILE_APPEND);
        file_put_contents($debugLog, "Nameservers: " . ($dnsResult['nameservers'][0] ?? 'ns1.bunny.net') . ", " . ($dnsResult['nameservers'][1] ?? 'ns2.bunny.net') . "\n", FILE_APPEND);
        
        logActivity("SeekaHost CDN: Created for {$domain}");
        
        return 'success';
        
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/create_debug.log', "EXCEPTION: " . $e->getMessage() . "\n", FILE_APPEND);
        logActivity('SeekaHost CDN Error: ' . $e->getMessage());
        return $e->getMessage();
    }
}

function seekahostcdn_SuspendAccount($params)
{
    return 'success';
}

function seekahostcdn_UnsuspendAccount($params)
{
    return 'success';
}

function seekahostcdn_TerminateAccount($params)
{
    try {
        require_once __DIR__ . '/lib/BunnyCDN.php';
        
        $apiKey = $params['serveraccesshash'];
        $bunny = new BunnyCDN_API($apiKey);
        
        $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')
            ->where('service_id', $params['serviceid'])
            ->first();
        
        if ($dnsInfo) {
            $bunny->deletePullZone($dnsInfo->pull_zone_id);
            $bunny->deleteDNSZone($dnsInfo->dns_zone_id);
        }
        
        Capsule::table('mod_seekahostcdn_dns_zones')
            ->where('service_id', $params['serviceid'])
            ->delete();
        
        Capsule::table('tblhosting')
            ->where('id', $params['serviceid'])
            ->update(['dedicatedip' => '']);
        
        return 'success';
        
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

function seekahostcdn_ClientArea($params)
{
    // SUPER DEBUG - Log ALL incoming requests
    $debugLog = __DIR__ . '/client_incoming.log';
    file_put_contents($debugLog, "\n=== " . date('Y-m-d H:i:s') . " ===\n", FILE_APPEND);
    file_put_contents($debugLog, "POST data: " . print_r($_POST, true), FILE_APPEND);
    file_put_contents($debugLog, "GET data: " . print_r($_GET, true), FILE_APPEND);
    file_put_contents($debugLog, "Service ID: " . ($params['serviceid'] ?? 'N/A') . "\n", FILE_APPEND);
    // Get zone ID - first try from params, then from database
    $zoneId = $params['dedicatedip'] ?? '';
    
    // Fallback: If not in params, fetch from database
    if (empty($zoneId)) {
        $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')
            ->where('service_id', $params['serviceid'])
            ->first();
        $zoneId = $dnsInfo->pull_zone_id ?? '';
    }
    
    // Get DNS zone information from database
    $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')
        ->where('service_id', $params['serviceid'])
        ->first();
    
    // Handle DNS record actions
    $message = '';
    $apiKey = $params['serveraccesshash'] ?? '';
    
    // Fallback API key if not in params
    if (empty($apiKey)) {
        $serverData = Capsule::table('tblservers')
            ->where('type', 'seekahostcdn')
            ->first();
        $apiKey = $serverData->accesshash ?? '';
    }
    
    if (!empty($apiKey) && !empty($dnsInfo)) {
        require_once __DIR__ . '/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($apiKey);
        $dnsZoneId = $dnsInfo->dns_zone_id;
        
        // Handle Add Record
        if (isset($_POST['action']) && $_POST['action'] == 'add_record') {
            $recordData = [
                'Type' => intval($_POST['type']),
                'Name' => trim($_POST['name']),
                'Value' => trim($_POST['value']),
                'Ttl' => intval($_POST['ttl'] ?? 3600)
            ];
            
            $result = $bunny->addDNSRecord($dnsZoneId, $recordData);
            $message = $result['success'] ? 
                '<div class="alert alert-success">DNS record added successfully!</div>' : 
                '<div class="alert alert-danger">Failed to add record: ' . $result['error'] . '</div>';
        }
        
        // Handle Delete Record
        if (isset($_GET['delete_record'])) {
            $recordId = intval($_GET['delete_record']);
            $result = $bunny->deleteDNSRecord($dnsZoneId, $recordId);
            $message = $result['success'] ? 
                '<div class="alert alert-success">DNS record deleted successfully!</div>' : 
                '<div class="alert alert-danger">Failed to delete record.</div>';
        }
        
        // Handle Cache Purge
        if (isset($_POST['modaction']) && $_POST['modaction'] == 'purge') {
            try {
                $bunny->purgeCache($zoneId);
                $message = '<div class="alert alert-success">Cache purged successfully!</div>';
            } catch (Exception $e) {
                $message = '<div class="alert alert-danger">Purge failed: ' . $e->getMessage() . '</div>';
            }
        }
        
        // Fetch current DNS records
$recordsResult = $bunny->getDNSRecords($dnsZoneId);

if (is_array($recordsResult) && !empty($recordsResult['success']) && isset($recordsResult['records'])) {
    $dnsRecords = $recordsResult['records'];

    // Decode if string
    if (is_string($dnsRecords)) {
        $decoded = json_decode($dnsRecords, true);
        $dnsRecords = is_array($decoded) ? $decoded : [];
    }

    // Ensure it's an array
    if (!is_array($dnsRecords)) {
        $dnsRecords = [];
    }

    //  CRITICAL FIX: sanitize each record
    $cleanRecords = [];
    foreach ($dnsRecords as $record) {
        if (is_string($record)) {
            $decoded = json_decode($record, true);
            if (is_array($decoded)) {
                $cleanRecords[] = $decoded;
            }
        } elseif (is_array($record)) {
            $cleanRecords[] = $record;
        }
    }

    $dnsRecords = $cleanRecords;

} else {
    $dnsRecords = [];
  }
    
    // If no zone ID or no DNS info, show pending
    if (empty($zoneId) || !$dnsInfo) {
        return array(
            'templatefile' => 'templates/client/pending',
            'vars' => array('message' => 'Your CDN zone is being provisioned. Please refresh.')
        );
    }
    
    // Map record types to readable names
    $recordTypes = [
        0 => 'A', 1 => 'AAAA', 2 => 'CNAME', 3 => 'TXT',
        4 => 'MX', 5 => 'NS', 6 => 'CAA', 7 => 'SRV'
    ];
    
    return array(
        'templatefile' => 'templates/client/overview',
        'vars' => array(
            'serviceid' => $params['serviceid'],
            'zoneId' => $zoneId,
            'domain' => $dnsInfo->domain ?? $params['domain'],
            'nameserver1' => $dnsInfo->nameserver_1 ?? 'ns1.bunny.net',
            'nameserver2' => $dnsInfo->nameserver_2 ?? 'ns2.bunny.net',
            'cdnUrl' => $dnsInfo->cdn_url ?? '',
            'originUrl' => $dnsInfo->origin_url ?? '',
            'message' => $message,
            'dnsRecords' => $dnsRecords,
            'recordTypes' => $recordTypes,
        )
    );
}
}