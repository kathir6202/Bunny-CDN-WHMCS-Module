<?php

// WHMCS AJAX Handler - Corrected Paths
header('Content-Type: application/json');

// Define WHMCS root path
$whmcsRoot = '/home/develpseekahost/public_html/';

// Load WHMCS core
require_once $whmcsRoot . 'init.php';

use WHMCS\Database\Capsule;

// Log for debugging
file_put_contents(__DIR__ . '/ajax_debug.log', 
    date('Y-m-d H:i:s') . " - Handler loaded\n" .
    "REQUEST_METHOD: " . $_SERVER['REQUEST_METHOD'] . "\n" .
    "GET: " . print_r($_GET, true) . "\n" .
    "POST: " . print_r($_POST, true) . "\n",
    FILE_APPEND
);

// Security: Only allow logged-in clients
if (!isset($_SESSION['uid'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

// Get parameters from either GET or POST
$params = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;

// DEBUG: Log what we received
file_put_contents(__DIR__ . '/ajax_params.log', 
    date('Y-m-d H:i:s') . "\n" .
    "Method: " . $_SERVER['REQUEST_METHOD'] . "\n" .
    "Params: " . print_r($params, true) . "\n",
    FILE_APPEND
);

$action = $params['dns_action'] ?? '';
$serviceId = intval($params['service_id'] ?? 0);

// Verify client owns this service
try {
    $service = Capsule::table('tblhosting')
        ->where('id', $serviceId)
        ->where('userid', $_SESSION['uid'])
        ->first();
    
    if (!$service) {
        echo json_encode(['success' => false, 'error' => 'Service not found or access denied']);
        exit;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    exit;
}

// Handle Add Record
if ($action === 'add_record') {
    try {
        $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')
            ->where('service_id', $serviceId)
            ->first();
        
        if (!$dnsInfo) {
            echo json_encode(['success' => false, 'error' => 'DNS zone not found']);
            exit;
        }
        
        $serverData = Capsule::table('tblservers')
            ->where('type', 'seekahostcdn')
            ->first();
        
        $apiKey = $serverData->accesshash ?? '';
        
        if (empty($apiKey)) {
            echo json_encode(['success' => false, 'error' => 'API key not configured']);
            exit;
        }
        
        require_once __DIR__ . '/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($apiKey);
        
        $recordData = [
            'Type' => intval($params['type']),
            'Name' => trim($params['name']),
            'Value' => trim($params['value']),
            'Ttl' => intval($params['ttl'] ?? 3600),
            'Accelerated' => filter_var(($params['accelerated'] ?? 'true'), FILTER_VALIDATE_BOOLEAN)
        ];
        
        file_put_contents(__DIR__ . '/ajax_debug.log', 
            "Record data: " . print_r($recordData, true) . "\n" .
            "DNS Zone ID: " . $dnsInfo->dns_zone_id . "\n",
            FILE_APPEND
        );
        
        $result = $bunny->addDNSRecord($dnsInfo->dns_zone_id, $recordData);
        
        file_put_contents(__DIR__ . '/ajax_debug.log', 
            "API Result: " . print_r($result, true) . "\n",
            FILE_APPEND
        );
        
        echo json_encode($result);
        exit;
        
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/ajax_debug.log', 
            "Exception: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// Handle Delete Record
if ($action === 'delete_record') {
    try {
        $recordId = intval($params['record_id'] ?? 0);
        
        $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')
            ->where('service_id', $serviceId)
            ->first();
        
        if (!$dnsInfo) {
            echo json_encode(['success' => false, 'error' => 'DNS zone not found']);
            exit;
        }
        
        $serverData = Capsule::table('tblservers')
            ->where('type', 'seekahostcdn')
            ->first();
        
        $apiKey = $serverData->accesshash ?? '';
        
        if (empty($apiKey)) {
            echo json_encode(['success' => false, 'error' => 'API key not configured']);
            exit;
        }
        
        require_once __DIR__ . '/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($apiKey);
        
        $result = $bunny->deleteDNSRecord($dnsInfo->dns_zone_id, $recordId);
        
        echo json_encode($result);
        exit;
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// Handle Purge Cache
if ($action === 'purge_cache') {
    try {
        $serverData = Capsule::table('tblservers')
            ->where('type', 'seekahostcdn')
            ->first();
        
        $apiKey = $serverData->accesshash ?? '';
        
        if (empty($apiKey)) {
            echo json_encode(['success' => false, 'error' => 'API key not configured']);
            exit;
        }
        
        require_once __DIR__ . '/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($apiKey);
        
        $bunny->purgeCache($service->dedicatedip);
        
        echo json_encode(['success' => true]);
        exit;
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// Handle Get Statistics
if ($action === 'get_stats') {
    try {
        $period = $params['period'] ?? '30d';
        $zoneId = $service->dedicatedip ?? '';
        
        if (empty($zoneId)) {
            echo json_encode(['success' => false, 'error' => 'Zone ID not found']);
            exit;
        }
        
        $serverData = Capsule::table('tblservers')
            ->where('type', 'seekahostcdn')
            ->first();
        
        $apiKey = $serverData->accesshash ?? '';
        
        if (empty($apiKey)) {
            echo json_encode(['success' => false, 'error' => 'API key not configured']);
            exit;
        }
        
        require_once __DIR__ . '/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($apiKey);
        
        $result = $bunny->getDetailedStatistics($zoneId, $period);
        
        // DEBUG: Log the full result
        file_put_contents(__DIR__ . '/stats_debug.log', 
            date('Y-m-d H:i:s') . " - Stats Result:\n" . print_r($result, true) . "\n", 
            FILE_APPEND
        );
        
        echo json_encode($result);
        exit;
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// Invalid action
echo json_encode(['success' => false, 'error' => 'Invalid action: ' . $action]);
exit;