<div class="alert alert-info">
    <i class="fa fa-spinner fa-spin"></i>
    <strong>Provisioning in Progress</strong>
    <p>{$message|default:"Your CDN service is being set up. This usually takes 1-2 minutes."}</p>
    <p><small>Refresh this page to check if provisioning is complete.</small></p>
</div>

<script>
// Auto-refresh after 30 seconds
setTimeout(function() {ldelim}
    location.reload();
{rdelim}, 30000);
</script>