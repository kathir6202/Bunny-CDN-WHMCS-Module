{$message}

{if $smarty.get.dns == 'added'}
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        DNS record added successfully!
    </div>
{/if}

{if $smarty.get.dns == 'deleted'}
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        DNS record deleted successfully!
    </div>
{/if}

{if $smarty.get.cache == 'purged'}
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        Cache purged successfully!
    </div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">
            <i class="fa fa-globe"></i> Nameserver Configuration
        </h4>
    </div>
    <div class="panel-body">
        <div class="alert alert-success">
            <strong>Full-Site CDN Ready!</strong> Update your nameservers to activate.
        </div>
        
        <p><strong>Your Domain:</strong> <code>{$domain}</code></p>
        
        <h5>Update these nameservers at your domain registrar:</h5>
        
        <table class="table table-bordered" style="width: auto;">
            <tr>
                <td><strong>Primary Nameserver:</strong></td>
                <td><code>{$nameserver1}</code></td>
                <td><button type="button" class="btn btn-xs btn-default" onclick="copyToClipboard('{$nameserver1}')">Copy</button></td>
            </tr>
            <tr>
                <td><strong>Secondary Nameserver:</strong></td>
                <td><code>{$nameserver2}</code></td>
                <td><button type="button" class="btn btn-xs btn-default" onclick="copyToClipboard('{$nameserver2}')">Copy</button></td>
            </tr>
        </table>
        
        <div class="alert alert-info">
            <i class="fa fa-info-circle"></i>
            <strong>Important:</strong> DNS changes take 24-48 hours to propagate.
        </div>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">CDN Information</h4>
    </div>
    <div class="panel-body">
        <table class="table table-striped">
            <tr>
                <td width="200"><strong>CDN URL:</strong></td>
                <td><code>{$cdnUrl}</code></td>
            </tr>
            <tr>
                <td><strong>Zone ID:</strong></td>
                <td><code>{$zoneId}</code></td>
            </tr>
            <tr>
                <td><strong>Origin Server:</strong></td>
                <td><code>{$originUrl}</code></td>
            </tr>
        </table>
    </div>
</div>

<!-- Monthly Usage Statistics -->
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">
            <i class="fa fa-bar-chart"></i> Monthly Usage
        </h4>
    </div>
    <div class="panel-body">
        <div class="row" id="statsSummary">
            <div class="col-md-4">
                <div class="well text-center">
                    <h3 style="margin: 0; color: #3c8dbc;" id="statBandwidth">--</h3>
                    <p class="text-muted">Bandwidth Used</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="well text-center">
                    <h3 style="margin: 0; color: #00a65a;" id="statCost">--</h3>
                    <p class="text-muted">Monthly Charges</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="well text-center">
                    <h3 style="margin: 0; color: #f39c12;" id="statLimit">--</h3>
                    <p class="text-muted">Bandwidth Limit</p>
                </div>
            </div>
        </div>
        
        <div id="statsLoading" style="display: none; text-align: center; padding: 20px;">
            <i class="fa fa-spinner fa-spin fa-2x"></i>
            <p class="text-muted">Loading statistics...</p>
        </div>
    </div>
</div>

<!-- DNS Records Management -->
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">
            <i class="fa fa-table"></i> DNS Records
        </h4>
    </div>
    <div class="panel-body">
        <div id="dnsMessage"></div>
        
        <h5>Current Records</h5>
        <div id="dnsRecordsTable">
            {if isset($dnsRecords) && is_array($dnsRecords) && count($dnsRecords) > 0}
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Name</th>
                            <th>Value</th>
                            <th>CDN</th>
                            <th>TTL</th>
                            <th width="100">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {foreach from=$dnsRecords item=record}
                        <tr id="record-{$record.Id}">
                            <td>
                                {if $record.Type == 0}<span class="label label-primary">A</span>
                                {elseif $record.Type == 1}<span class="label label-info">AAAA</span>
                                {elseif $record.Type == 2}<span class="label label-success">CNAME</span>
                                {elseif $record.Type == 3}<span class="label label-warning">TXT</span>
                                {elseif $record.Type == 4}<span class="label label-danger">MX</span>
                                {elseif $record.Type == 5}<span class="label label-default">NS</span>
                                {else}<span class="label label-default">Type {$record.Type|default:'?'}</span>
                                {/if}
                            </td>
                            <td><code>{$record.Name|default:''}</code></td>
                            <td><code>{$record.Value|default:''|truncate:50}</code></td>
                            <td>
                                {if $record.Accelerated}
                                    <span class="label label-success"><i class="fa fa-bolt"></i> Enabled</span>
                                {else}
                                    <span class="label label-default"><i class="fa fa-minus"></i> Disabled</span>
                                {/if}
                            </td>
                            <td>{$record.Ttl|default:'3600'}s</td>
                            <td>
                                <button type="button" class="btn btn-xs btn-danger" onclick="deleteDNSRecord({$record.Id})">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </td>
                        </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
            {else}
            <p class="text-muted" id="noRecordsMsg">No DNS records found.</p>
            {/if}
        </div>
        
        <hr>
        
        <h5>Add Record</h5>
        <form id="addDnsForm" onsubmit="addDNSRecord(event)">
            <div class="form-group">
                <label class="control-label">Record Type</label>
                <select name="type" id="dnsType" class="form-control" required style="max-width: 300px;">
                    <option value="0">A (IPv4 Address)</option>
                    <option value="1">AAAA (IPv6 Address)</option>
                    <option value="2">CNAME (Alias)</option>
                    <option value="3">TXT (Text)</option>
                    <option value="4">MX (Mail Exchange)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label class="control-label">Name</label>
                <input type="text" name="name" id="dnsName" class="form-control" 
                       placeholder="@ for root, www for subdomain" required style="max-width: 400px;">
            </div>
            
            <div class="form-group">
                <label class="control-label">Value</label>
                <input type="text" name="value" id="dnsValue" class="form-control" 
                       placeholder="e.g., 192.168.1.1 or target.domain.com" required style="max-width: 500px;">
            </div>
            
            <div class="form-group">
                <label class="control-label">TTL</label>
                <select name="ttl" id="dnsTtl" class="form-control" style="max-width: 200px;">
                    <option value="300">5 minutes</option>
                    <option value="3600" selected>1 hour</option>
                    <option value="14400">4 hours</option>
                    <option value="86400">24 hours</option>
                </select>
            </div>
            
            <div class="form-group">
                <div class="checkbox">
                    <label>
                        <input type="checkbox" name="accelerated" id="dnsAccelerated" value="1" checked>
                        <strong>Enable CDN Acceleration</strong>
                    </label>
                </div>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary" id="addRecordBtn">
                    <i class="fa fa-plus"></i> Add Record
                </button>
                <span id="addSpinner" style="display: none; margin-left: 10px;">
                    <i class="fa fa-spinner fa-spin"></i> Adding...
                </span>
            </div>
        </form>
    </div>
</div>

<!-- Cache Management -->
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">Cache Management</h4>
    </div>
    <div class="panel-body">
        <div id="cacheMessage"></div>
        
        <button type="button" class="btn btn-warning" onclick="purgeCache()" id="purgeCacheBtn">
            <i class="fa fa-refresh"></i> Purge Cache
        </button>
        <span id="purgeSpinner" style="display: none; margin-left: 10px;">
            <i class="fa fa-spinner fa-spin"></i> Purging...
        </span>
    </div>
</div>

<script>
var serviceId = {$serviceid};

function copyToClipboard(text) {ldelim}
    navigator.clipboard.writeText(text).then(function() {ldelim}
        alert('Copied: ' + text);
    {rdelim}).catch(function(err) {ldelim}
        console.error('Failed to copy: ', err);
    {rdelim});
{rdelim}

function showMessage(type, text) {ldelim}
    var msgDiv = document.getElementById('dnsMessage');
    msgDiv.innerHTML = '<div class="alert alert-' + (type === 'success' ? 'success' : 'danger') + ' alert-dismissible">' +
        '<button type="button" class="close" data-dismiss="alert">&times;</button>' + text + '</div>';
    setTimeout(function() {ldelim} 
        msgDiv.innerHTML = ''; 
    {rdelim}, 5000);
{rdelim}

function addDNSRecord(event) {ldelim}
    event.preventDefault();
    
    var btn = document.getElementById('addRecordBtn');
    var spinner = document.getElementById('addSpinner');
    
    btn.disabled = true;
    spinner.style.display = 'inline';
    
    var params = new URLSearchParams();
    params.append('dns_action', 'add_record');
    params.append('service_id', serviceId);
    params.append('type', document.getElementById('dnsType').value);
    params.append('name', document.getElementById('dnsName').value);
    params.append('value', document.getElementById('dnsValue').value);
    params.append('ttl', document.getElementById('dnsTtl').value);
    params.append('accelerated', document.getElementById('dnsAccelerated').checked ? 'true' : 'false');
    
    var url = '/modules/servers/seekahostcdn/ajax_handler.php?' + params.toString();
    
    fetch(url, {ldelim}
        method: 'GET',
        credentials: 'same-origin'
    {rdelim})
    .then(response => response.json())
    .then(data => {ldelim}
        if (data.success) {ldelim}
            showMessage('success', 'DNS record added!');
            document.getElementById('addDnsForm').reset();
            document.getElementById('dnsAccelerated').checked = true;
            setTimeout(function() {ldelim} 
                window.location.href = window.location.pathname + '?action=productdetails&id=' + serviceId + '&dns=added';
            {rdelim}, 1000);
        {rdelim} else {ldelim}
            showMessage('error', 'Failed: ' + (data.error || 'Unknown error'));
        {rdelim}
    {rdelim})
    .catch(error => {ldelim}
        showMessage('error', 'Network error: ' + error);
    {rdelim})
    .finally(() => {ldelim}
        btn.disabled = false;
        spinner.style.display = 'none';
    {rdelim});
{rdelim}

function deleteDNSRecord(recordId) {ldelim}
    if (!confirm('Delete this record?')) {ldelim}
        return;
    {rdelim}
    
    var params = new URLSearchParams();
    params.append('dns_action', 'delete_record');
    params.append('service_id', serviceId);
    params.append('record_id', recordId);
    
    var url = '/modules/servers/seekahostcdn/ajax_handler.php?' + params.toString();
    
    fetch(url, {ldelim}
        method: 'GET',
        credentials: 'same-origin'
    {rdelim})
    .then(response => response.json())
    .then(data => {ldelim}
        if (data.success) {ldelim}
            window.location.href = window.location.pathname + '?action=productdetails&id=' + serviceId + '&dns=deleted';
        {rdelim} else {ldelim}
            alert('Failed: ' + (data.error || 'Unknown error'));
        {rdelim}
    {rdelim})
    .catch(error => {ldelim}
        alert('Network error: ' + error);
    {rdelim});
{rdelim}

function purgeCache() {ldelim}
    if (!confirm('Purge entire cache?')) {ldelim}
        return;
    {rdelim}
    
    var btn = document.getElementById('purgeCacheBtn');
    var spinner = document.getElementById('purgeSpinner');
    var msgDiv = document.getElementById('cacheMessage');
    
    btn.disabled = true;
    spinner.style.display = 'inline';
    
    var params = new URLSearchParams();
    params.append('dns_action', 'purge_cache');
    params.append('service_id', serviceId);
    
    var url = '/modules/servers/seekahostcdn/ajax_handler.php?' + params.toString();
    
    fetch(url, {ldelim}
        method: 'GET',
        credentials: 'same-origin'
    {rdelim})
    .then(response => response.json())
    .then(data => {ldelim}
        if (data.success) {ldelim}
            msgDiv.innerHTML = '<div class="alert alert-success alert-dismissible">' +
                '<button type="button" class="close" data-dismiss="alert">&times;</button>Cache purged!</div>';
        {rdelim} else {ldelim}
            msgDiv.innerHTML = '<div class="alert alert-danger alert-dismissible">' +
                '<button type="button" class="close" data-dismiss="alert">&times;</button>Failed: ' + (data.error || 'Unknown error') + '</div>';
        {rdelim}
        setTimeout(function() {ldelim} msgDiv.innerHTML = ''; {rdelim}, 5000);
    {rdelim})
    .catch(error => {ldelim}
        msgDiv.innerHTML = '<div class="alert alert-danger">Network error: ' + error + '</div>';
    {rdelim})
    .finally(() => {ldelim}
        btn.disabled = false;
        spinner.style.display = 'none';
    {rdelim});
{rdelim}

function loadStats() {ldelim}
    document.getElementById('statsSummary').style.opacity = '0.5';
    document.getElementById('statsLoading').style.display = 'block';
    
    var params = new URLSearchParams();
    params.append('dns_action', 'get_stats');
    params.append('service_id', serviceId);
    
    var url = '/modules/servers/seekahostcdn/ajax_handler.php?' + params.toString();
    
    fetch(url, {ldelim}
        method: 'GET',
        credentials: 'same-origin'
    {rdelim})
    .then(response => response.json())
    .then(data => {ldelim}
        if (data.success) {ldelim}
            document.getElementById('statBandwidth').textContent = data.summary.total_bandwidth_formatted;
            document.getElementById('statCost').textContent = '$' + (data.summary.monthly_charges || 0).toFixed(4);
            document.getElementById('statLimit').textContent = data.summary.bandwidth_limit_formatted;
        {rdelim}
    {rdelim})
    .catch(error => {ldelim}
        console.error('Error loading stats:', error);
    {rdelim})
    .finally(() => {ldelim}
        document.getElementById('statsSummary').style.opacity = '1';
        document.getElementById('statsLoading').style.display = 'none';
    {rdelim});
{rdelim}

document.addEventListener('DOMContentLoaded', function() {ldelim}
    loadStats();
{rdelim});
</script>

<style>
.panel-heading h4 {ldelim}
    margin: 0;
    padding: 0;
{rdelim}
.table > tbody > tr > td {ldelim}
    vertical-align: middle;
{rdelim}
.label {ldelim}
    font-size: 12px;
{rdelim}
#dnsMessage .alert, #cacheMessage .alert {ldelim}
    margin-bottom: 15px;
{rdelim}
.well {ldelim}
    padding: 15px;
    border-radius: 4px;
{rdelim}
</style>