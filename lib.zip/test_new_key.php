<?php
// Replace with your actual lengthy key
$apiKey = 'd59ce097-d695-4622-9daf-38ac6869b6d271d70126-2a42-45ca-b670-2abe588f78b2';

echo "Key length: " . strlen($apiKey) . "\n\n";

// Test pullzone endpoint
$ch = curl_init('https://api.bunny.net/pullzone');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'AccessKey: ' . $apiKey,
    'Accept: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "PullZone Test:\n";
echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . substr($response, 0, 200) . "\n\n";

// Test DNS zone endpoint
$ch2 = curl_init('https://api.bunny.net/dnszone');
curl_setopt($ch2, CURLOPT_HTTPHEADER, [
    'AccessKey: ' . $apiKey,
    'Accept: application/json'
]);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
$response2 = curl_exec($ch2);
$httpCode2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
curl_close($ch2);

echo "DNS Zone Test:\n";
echo "HTTP Code: " . $httpCode2 . "\n";
echo "Response: " . substr($response2, 0, 200) . "\n";