<?php

class BunnyCDN_API {
    private $apiKey;
    private $baseUrl = 'https://api.bunny.net';
    
    // Record type constants
    const TYPE_A = 0;
    const TYPE_AAAA = 1;
    const TYPE_CNAME = 2;
    const TYPE_TXT = 3;
    const TYPE_MX = 4;
    const TYPE_NS = 5;
    const TYPE_CAA = 6;
    const TYPE_SRV = 7;
    
    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
    }
    
    /**
     * Create a DNS Zone
     */
    public function createDNSZone($domain) {
        $data = ['Domain' => $domain];
        $response = $this->request('/dnszone', 'POST', $data);
        
        $this->log("createDNSZone FULL response: " . json_encode($response));
        $this->log("All response keys: " . implode(', ', array_keys($response)));
        
        if (isset($response['Id'])) {
            $nameservers = ['ns1.bunny.net', 'ns2.bunny.net'];
            
            if (isset($response['Nameservers']) && is_array($response['Nameservers']) && count($response['Nameservers']) >= 2) {
                $nameservers = $response['Nameservers'];
                $this->log("Nameservers found: " . implode(', ', $nameservers));
            } elseif (isset($response['Nameserver1']) && isset($response['Nameserver2'])) {
                $nameservers = [$response['Nameserver1'], $response['Nameserver2']];
                $this->log("Nameservers found (1/2): " . implode(', ', $nameservers));
            } else {
                $this->log("Nameservers NOT found in response, using defaults");
            }
            
            return [
                'success' => true,
                'zone_id' => $response['Id'],
                'domain' => $response['Domain'],
                'nameservers' => $nameservers
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to create DNS zone'
        ];
    }
    
    /**
     * Get DNS Zone information including nameservers
     */
    public function getDNSZoneInfo($zoneId) {
        $response = $this->request('/dnszone/' . $zoneId, 'GET');
        
        $this->log("getDNSZoneInfo response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            $nameservers = ['ns1.bunny.net', 'ns2.bunny.net'];
            
            if (isset($response['Nameservers']) && is_array($response['Nameservers']) && count($response['Nameservers']) >= 2) {
                $nameservers = $response['Nameservers'];
            } elseif (isset($response['Nameserver1']) && isset($response['Nameserver2'])) {
                $nameservers = [$response['Nameserver1'], $response['Nameserver2']];
            }
            
            return [
                'success' => true,
                'zone_id' => $response['Id'],
                'domain' => $response['Domain'] ?? '',
                'nameservers' => $nameservers,
                'nameserver1' => $nameservers[0] ?? 'ns1.bunny.net',
                'nameserver2' => $nameservers[1] ?? 'ns2.bunny.net'
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to get DNS zone info'
        ];
    }
    
    /**
     * Get DNS Zone statistics (includes all linked Pull Zones)
     * NOTE: Bunny DNS Zone API doesn't provide usage stats directly.
     * This returns zone configuration info. For traffic stats, use getDetailedStatistics on each Pull Zone.
     */
    public function getDNSZoneStatistics($dnsZoneId) {
        $response = $this->request('/dnszone/' . $dnsZoneId, 'GET');
        
        $this->log("getDNSZoneStatistics response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            return [
                'success' => true,
                'domain' => $response['Domain'] ?? '',
                'nameserver1' => $response['Nameserver1'] ?? 'ns1.bunny.net',
                'nameserver2' => $response['Nameserver2'] ?? 'ns2.bunny.net',
                'logging_enabled' => $response['LoggingEnabled'] ?? false,
                'date_modified' => $response['DateModified'] ?? '',
                'date_created' => $response['DateCreated'] ?? ''
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to fetch DNS zone info'
        ];
    }
    
    /**
     * Create a Pull Zone
     */
    public function createPullZone($name, $originUrl) {
        $data = [
            'Name' => $name,
            'OriginUrl' => $originUrl,
            'Type' => 0
        ];
        
        $response = $this->request('/pullzone', 'POST', $data);
        
        $this->log("createPullZone response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            return [
                'success' => true,
                'zone_id' => $response['Id'],
                'cdn_url' => $response['Hostnames'][0]['Value'] ?? $name . '.b-cdn.net'
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to create pull zone'
        ];
    }
    
    /**
     * Link DNS Zone to Pull Zone (creates CNAME record for www subdomain)
     */
    public function linkDNSToPullZone($dnsZoneId, $pullZoneId) {
        $data = [
            'Type' => 2,
            'Name' => 'www',
            'Value' => $pullZoneId . '.b-cdn.net',
            'Ttl' => 3600,
            'Accelerated' => true
        ];
        
        $response = $this->request('/dnszone/' . $dnsZoneId . '/records', 'PUT', $data);
        
        return [
            'success' => isset($response['Id']),
            'error' => $response['Message'] ?? null
        ];
    }
    
    public function deleteDNSZone($zoneId) {
        return $this->request('/dnszone/' . $zoneId, 'DELETE');
    }
    
    public function deletePullZone($zoneId) {
        return $this->request('/pullzone/' . $zoneId, 'DELETE');
    }
    
    public function purgeCache($zoneId) {
        return $this->request('/pullzone/' . $zoneId . '/purgeCache', 'POST');
    }
    
    public function getStatistics($zoneId) {
        return $this->request('/pullzone/' . $zoneId, 'GET');
    }
    
    // ==================== DNS RECORD MANAGEMENT METHODS ====================
    
    /**
     * Get all DNS records for a zone
     */
    public function getDNSRecords($zoneId) {
        $response = $this->request('/dnszone/' . $zoneId . '/records', 'GET');
        
        if (is_array($response)) {
            return [
                'success' => true,
                'records' => $response
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to fetch DNS records'
        ];
    }
    
    /**
     * Add a new DNS record to a zone (uses PUT)
     */
    public function addDNSRecord($zoneId, $data) {
        if (isset($data['Accelerated'])) {
            $data['Accelerated'] = (bool)$data['Accelerated'];
        }
        
        $response = $this->request('/dnszone/' . $zoneId . '/records', 'PUT', $data);
        
        $this->log("addDNSRecord response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            return [
                'success' => true,
                'record_id' => $response['Id'],
                'record' => $response
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to add DNS record'
        ];
    }
    
    /**
     * Add multiple DNS records at once
     */
    public function addBulkDNSRecords($zoneId, $records) {
        $results = [
            'success' => true,
            'added' => 0,
            'failed' => 0,
            'errors' => []
        ];
        
        foreach ($records as $record) {
            $result = $this->addDNSRecord($zoneId, $record);
            if ($result['success']) {
                $results['added']++;
            } else {
                $results['failed']++;
                $results['errors'][] = [
                    'record' => ($record['Name'] ?? '?') . ' ' . ($record['Type'] ?? '?'),
                    'error' => $result['error']
                ];
                $results['success'] = false;
            }
        }
        
        return $results;
    }
    
    /**
     * Update an existing DNS record (uses PUT)
     */
    public function updateDNSRecord($zoneId, $recordId, $data) {
        $response = $this->request('/dnszone/' . $zoneId . '/records/' . $recordId, 'PUT', $data);
        
        $this->log("updateDNSRecord response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            return [
                'success' => true,
                'record' => $response
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to update DNS record'
        ];
    }
    
    /**
     * Delete a DNS record
     */
    public function deleteDNSRecord($zoneId, $recordId) {
        $response = $this->request('/dnszone/' . $zoneId . '/records/' . $recordId, 'DELETE');
        
        $this->log("deleteDNSRecord response: " . json_encode($response));
        
        return [
            'success' => true
        ];
    }
    
    // ==================== STATISTICS METHODS ====================
    
    /**
     * Get bandwidth usage from pull zone details
     */
    public function getBandwidthUsage($zoneId, $startDate = null, $endDate = null) {
        $endpoint = '/pullzone/' . $zoneId;
        $response = $this->request($endpoint, 'GET');
        
        $this->log("getBandwidthUsage response: " . json_encode($response));
        
        if (isset($response['Id'])) {
            return [
                'success' => true,
                'statistics' => $response
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['Message'] ?? 'Failed to fetch statistics'
        ];
    }
    
    /**
     * Get total bandwidth for current month (in bytes)
     */
    public function getMonthlyBandwidth($zoneId) {
        $result = $this->getBandwidthUsage($zoneId);
        
        if ($result['success'] && isset($result['statistics']['MonthlyBandwidthUsed'])) {
            $totalBytes = $result['statistics']['MonthlyBandwidthUsed'] ?? 0;
            return [
                'success' => true,
                'total_bytes' => $totalBytes,
                'total_gb' => round($totalBytes / (1024 * 1024 * 1024), 2)
            ];
        }
        
        return $result;
    }
    
    /**
     * Get total requests for current month
     */
    public function getMonthlyRequests($zoneId) {
        $result = $this->getBandwidthUsage($zoneId);
        
        if ($result['success'] && isset($result['statistics']['Id'])) {
            return [
                'success' => true,
                'total_requests' => $result['statistics']['TotalRequests'] ?? 0,
                'total_hits' => 0,
                'cache_hit_ratio' => 0
            ];
        }
        
        return $result;
    }
    
    /**
     * Get detailed statistics from pull zone details
     */
    public function getDetailedStatistics($zoneId, $period = '30d') {
        $endpoint = '/pullzone/' . $zoneId;
        $zoneData = $this->request($endpoint, 'GET');
        
        $this->log("getDetailedStatistics zone data: " . json_encode($zoneData));
        
        if (isset($zoneData['Id'])) {
            $monthlyBandwidthBytes = $zoneData['MonthlyBandwidthUsed'] ?? 0;
            $monthlyCharges = $zoneData['MonthlyCharges'] ?? 0;
            $bandwidthLimit = $zoneData['MonthlyBandwidthLimit'] ?? 0;
            $totalRequests = $zoneData['TotalRequests'] ?? 0;
            
            $summary = [
                'total_bandwidth_gb' => round($monthlyBandwidthBytes / (1024 * 1024 * 1024), 2),
                'total_bandwidth_formatted' => $this->formatBytes($monthlyBandwidthBytes),
                'total_requests' => $totalRequests,
                'total_requests_formatted' => number_format($totalRequests),
                'total_hits' => 0,
                'cache_hit_ratio' => 0,
                'total_misses' => 0,
                'bandwidth_limit' => $bandwidthLimit,
                'bandwidth_limit_formatted' => $bandwidthLimit > 0 ? $this->formatBytes($bandwidthLimit * 1024 * 1024 * 1024) : 'Unlimited',
                'monthly_charges' => $monthlyCharges,
                'zone_enabled' => $zoneData['Enabled'] ?? true,
                'zone_suspended' => $zoneData['Suspended'] ?? false
            ];
            
            $chartData = [[
                'date' => date('Y-m-d'),
                'bandwidth' => round($monthlyBandwidthBytes / (1024 * 1024 * 1024), 4),
                'requests' => $totalRequests,
                'hits' => 0,
                'misses' => 0
            ]];
            
            return [
                'success' => true,
                'summary' => $summary,
                'chart_data' => $chartData
            ];
        }
        
        return [
            'success' => false,
            'error' => $zoneData['Message'] ?? 'Failed to fetch statistics'
        ];
    }
    
    // ==================== CORE REQUEST METHOD ====================
    
    private function request($endpoint, $method, $data = []) {
        $this->log("REQUEST: {$method} {$endpoint}");
        $this->log("API Key: '" . substr($this->apiKey, 0, 10) . "...' (length: " . strlen($this->apiKey) . ")");
        $this->log("Data: " . json_encode($data));
        
        $ch = curl_init($this->baseUrl . $endpoint);
        
        $headers = [
            'AccessKey: ' . trim($this->apiKey),
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        $this->log("RESPONSE: HTTP {$httpCode}");
        $this->log("Body: " . substr($response, 0, 500));
        
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            $this->log("CURL ERROR: " . $error);
            throw new Exception('CURL Error: ' . $error);
        }
        
        curl_close($ch);
        
        return json_decode($response, true);
    }
    
    private function log($message) {
        $logFile = __DIR__ . '/bunny_api_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[{$timestamp}] {$message}\n", FILE_APPEND);
    }
    
    /**
     * Format bytes to human readable format
     */
    private function formatBytes($bytes, $precision = 2) {
        if ($bytes <= 0) return '0 B';
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $pow = floor(log($bytes) / log(1024));
        $pow = min($pow, count($units) - 1);
        return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
    }
}