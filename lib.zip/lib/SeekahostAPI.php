<?php

class SeekahostAPI
{
    private $apiKey;
    private $apiUrl = 'https://api.seekahost.com/v1'; // Replace with your actual CDN API endpoint
    
    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }
    
    private function request($endpoint, $method = 'GET', $data = [])
    {
        $ch = curl_init($this->apiUrl . $endpoint);
        
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        if ($method === 'POST' || $method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new Exception('CURL Error: ' . curl_error($ch));
        }
        
        curl_close($ch);
        
        return [
            'code' => $httpCode,
            'body' => json_decode($response, true)
        ];
    }
    
    public function createPullZone($data)
    {
        $response = $this->request('/pull-zones', 'POST', $data);
        
        if ($response['code'] === 201) {
            return [
                'success' => true,
                'zone_id' => $response['body']['id'],
                'cdn_url' => $response['body']['cdn_url']
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['body']['message'] ?? 'Unknown error'
        ];
    }
    
    public function deletePullZone($zoneId)
    {
        $response = $this->request('/pull-zones/' . $zoneId, 'DELETE');
        
        return [
            'success' => ($response['code'] === 204),
            'error' => $response['body']['message'] ?? null
        ];
    }
    
    public function disablePullZone($zoneId)
    {
        return $this->updatePullZone($zoneId, ['enabled' => false]);
    }
    
    public function enablePullZone($zoneId)
    {
        return $this->updatePullZone($zoneId, ['enabled' => true]);
    }
    
    public function updatePullZone($zoneId, $data)
    {
        $response = $this->request('/pull-zones/' . $zoneId, 'PUT', $data);
        
        return [
            'success' => ($response['code'] === 200),
            'error' => $response['body']['message'] ?? null
        ];
    }
    
    public function getZoneStatistics($zoneId)
    {
        $response = $this->request('/pull-zones/' . $zoneId . '/statistics');
        
        if ($response['code'] === 200) {
            return $response['body'];
        }
        
        throw new Exception($response['body']['message'] ?? 'Failed to fetch statistics');
    }
    
    public function purgeCache($zoneId, $urls = [])
    {
        $data = empty($urls) ? ['purge_all' => true] : ['urls' => $urls];
        $response = $this->request('/pull-zones/' . $zoneId . '/purge', 'POST', $data);
        
        return [
            'success' => ($response['code'] === 202),
            'error' => $response['body']['message'] ?? null
        ];
    }
    
    public function getBandwidthUsage($zoneId, $startDate, $endDate)
    {
        $endpoint = "/pull-zones/{$zoneId}/bandwidth?start={$startDate}&end={$endDate}";
        $response = $this->request($endpoint);
        
        if ($response['code'] === 200) {
            return $response['body'];
        }
        
        throw new Exception($response['body']['message'] ?? 'Failed to fetch bandwidth usage');
    }
}