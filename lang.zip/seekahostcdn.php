<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

/**
 * Define addon module configuration
 * @return array
 */
function seekahostcdn_config()
{
    return [
        'name' => 'SeekaHost CDN for WHMCS',
        'description' => 'Fully integrates SeekaHost CDN into WHMCS with automated provisioning, usage tracking, and billing.',
        'version' => '1.0.0',
        'author' => 'SeekaHost',
        'language' => 'english',
        'fields' => [
            'api_key' => [
                'FriendlyName' => 'SeekaHost API Key',
                'Type' => 'password',
                'Size' => '50',
                'Description' => 'Enter your SeekaHost CDN API key'
            ],
            'price_per_gb' => [
                'FriendlyName' => 'Price per GB',
                'Type' => 'text',
                'Size' => '10',
                'Default' => '0.05',
                'Description' => 'Default price per GB for bandwidth usage'
            ],
            'billing_cycle' => [
                'FriendlyName' => 'Billing Cycle',
                'Type' => 'dropdown',
                'Options' => [
                    'monthly' => 'Monthly',
                    'daily' => 'Daily'
                ],
                'Default' => 'monthly',
                'Description' => 'How often to bill for bandwidth usage'
            ],
            'license_key' => [
                'FriendlyName' => 'License Key',
                'Type' => 'text',
                'Size' => '40',
                'Description' => 'Enter your SeekaHost CDN license key'
            ]
        ]
    ];
}

function seekahostcdn_activate()
{
    try {
        if (!Capsule::schema()->hasTable('mod_seekahostcdn_usage')) {
            Capsule::schema()->create('mod_seekahostcdn_usage', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('zone_id');
                $table->date('usage_date');
                $table->bigInteger('bandwidth_bytes');
                $table->decimal('cost', 10, 4);
                $table->integer('invoice_id')->nullable();
                $table->boolean('invoiced')->default(0);
                $table->timestamps();
                $table->index(['service_id', 'usage_date']);
                $table->unique(['service_id', 'usage_date']);
            });
        }
        
        if (!Capsule::schema()->hasTable('mod_seekahostcdn_hostnames')) {
            Capsule::schema()->create('mod_seekahostcdn_hostnames', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('hostname_id');
                $table->string('hostname');
                $table->boolean('verified')->default(false);
                $table->string('verification_record')->nullable();
                $table->boolean('ssl_enabled')->default(false);
                $table->string('ssl_certificate_id')->nullable();
                $table->string('ssl_status')->nullable();
                $table->timestamp('ssl_expires_at')->nullable();
                $table->timestamps();
            });
        }
        
        if (!Capsule::schema()->hasTable('mod_seekahostcdn_requests')) {
            Capsule::schema()->create('mod_seekahostcdn_requests', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('zone_id');
                $table->date('date');
                $table->bigInteger('total_requests');
                $table->bigInteger('cache_hits');
                $table->bigInteger('cache_misses');
                $table->decimal('cache_hit_ratio', 5, 2);
                $table->timestamps();
                $table->index(['service_id', 'date']);
                $table->unique(['service_id', 'date']);
            });
        }
        
        if (!Capsule::schema()->hasTable('mod_seekahostcdn_ssl_queue')) {
            Capsule::schema()->create('mod_seekahostcdn_ssl_queue', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('hostname');
                $table->string('certificate_id');
                $table->string('status');
                $table->integer('check_count')->default(0);
                $table->timestamp('last_check')->nullable();
                $table->timestamps();
            });
        }
        
        if (!Capsule::schema()->hasTable('mod_seekahostcdn_billing')) {
            Capsule::schema()->create('mod_seekahostcdn_billing', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('billing_month', 7);
                $table->decimal('bandwidth_gb', 10, 4)->default(0);
                $table->decimal('cost', 10, 2)->default(0);
                $table->integer('invoice_id')->nullable();
                $table->timestamp('created_at')->nullable();
                $table->unique(['service_id', 'billing_month']);
            });
        }
        
        return ['status' => 'success', 'description' => 'SeekaHost CDN activated successfully.'];
        
    } catch (Exception $e) {
        return ['status' => 'error', 'description' => 'Failed to create tables: ' . $e->getMessage()];
    }
}

function seekahostcdn_deactivate()
{
    return ['status' => 'success', 'description' => 'SeekaHost CDN deactivated'];
}

function seekahostcdn_output($vars)
{
    $modulelink = $vars['modulelink'];
    $action = $_GET['action'] ?? 'dashboard';
    $LANG = $vars['_lang'];
    
    if (isset($_POST['save_settings'])) {
        saveSettings($_POST);
        echo '<div class="alert alert-success">Settings saved successfully!</div>';
    }
    
    echo '<ul class="nav nav-tabs" style="margin-bottom: 20px;">
        <li class="' . ($action == 'dashboard' ? 'active' : '') . '">
            <a href="' . $modulelink . '"><i class="fa fa-dashboard"></i> Dashboard</a>
        </li>
        <li class="' . ($action == 'zones' ? 'active' : '') . '">
            <a href="' . $modulelink . '&action=zones"><i class="fa fa-globe"></i> Manage Zones</a>
        </li>
        <li class="' . ($action == 'billing' ? 'active' : '') . '">
            <a href="' . $modulelink . '&action=billing"><i class="fa fa-credit-card"></i> Billing</a>
        </li>
        <li class="' . ($action == 'settings' ? 'active' : '') . '">
            <a href="' . $modulelink . '&action=settings"><i class="fa fa-cog"></i> Settings</a>
        </li>
        <li class="' . ($action == 'help' ? 'active' : '') . '">
            <a href="' . $modulelink . '&action=help"><i class="fa fa-question-circle"></i> Help</a>
        </li>
    </ul>';
    
    if ($action == 'dashboard') {
        showDashboard();
    } elseif ($action == 'zones') {
        showZonesList();
    } elseif ($action == 'billing') {
        showBillingHistory();
    } elseif ($action == 'settings') {
        showSettingsForm();
    } elseif ($action == 'help') {
        showHelpPage();
    } else {
        showDashboard();
    }
}

function showDashboard()
{
    $activeZones = getActiveZonesCount();
    $monthlyBandwidth = formatBytes(getMonthlyBandwidthTotal());
    $totalClients = getTotalCDNClients();
    $recentZones = getRecentZones(5);
    $totalBilled = getTotalBilledThisMonth();
    
    echo '<div class="row">';
    echo '<div class="col-md-3"><div class="panel panel-default"><div class="panel-heading"><h4>Active CDN Zones</h4></div><div class="panel-body text-center"><h1 style="font-size:48px;margin:0;">' . $activeZones . '</h1><p class="text-muted">Currently active</p></div></div></div>';
    echo '<div class="col-md-3"><div class="panel panel-default"><div class="panel-heading"><h4>Monthly Bandwidth</h4></div><div class="panel-body text-center"><h1 style="font-size:48px;margin:0;">' . $monthlyBandwidth . '</h1><p class="text-muted">This month</p></div></div></div>';
    echo '<div class="col-md-3"><div class="panel panel-default"><div class="panel-heading"><h4>CDN Clients</h4></div><div class="panel-body text-center"><h1 style="font-size:48px;margin:0;">' . $totalClients . '</h1><p class="text-muted">Total clients</p></div></div></div>';
    echo '<div class="col-md-3"><div class="panel panel-default"><div class="panel-heading"><h4>Billed This Month</h4></div><div class="panel-body text-center"><h1 style="font-size:48px;margin:0;">$' . number_format($totalBilled, 2) . '</h1><p class="text-muted">Total invoiced</p></div></div></div>';
    echo '</div>';
    
    echo '<div class="panel panel-default"><div class="panel-heading"><h4>Recently Created Zones</h4></div><div class="panel-body">';
    if (count($recentZones) > 0) {
        echo '<table class="table table-striped"><thead><tr><th>Client</th><th>Domain</th><th>Zone ID</th><th>Created</th><th>Status</th></tr></thead><tbody>';
        foreach ($recentZones as $zone) {
            echo '<tr><td><a href="clientssummary.php?userid=' . $zone->userid . '">' . htmlspecialchars($zone->firstname . ' ' . $zone->lastname) . '</a></td><td>' . htmlspecialchars($zone->domain) . '</td><td><code>' . htmlspecialchars($zone->dedicatedip) . '</code></td><td>' . date('M j, Y', strtotime($zone->created_at)) . '</td><td><span class="label label-success">' . $zone->domainstatus . '</span></td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="text-muted">No zones created yet.</p>';
    }
    echo '</div></div>';
}

function showZonesList()
{
    $zones = getAllActiveZones();
    
    echo '<div class="panel panel-default"><div class="panel-heading"><h4>All CDN Zones</h4></div><div class="panel-body">';
    if (count($zones) > 0) {
        echo '<table class="table table-striped"><thead><tr><th>ID</th><th>Client</th><th>Domain</th><th>Zone ID</th><th>Bandwidth Used</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        foreach ($zones as $zone) {
            $bandwidth = getZoneBandwidthThisMonth($zone->id);
            echo '<tr><td>' . $zone->id . '</td><td><a href="clientssummary.php?userid=' . $zone->userid . '">' . htmlspecialchars($zone->firstname . ' ' . $zone->lastname) . '</a></td><td>' . htmlspecialchars($zone->domain) . '</td><td><code>' . htmlspecialchars($zone->dedicatedip) . '</code></td><td>' . formatBytes($bandwidth) . '</td><td><span class="label label-' . ($zone->domainstatus == 'Active' ? 'success' : 'warning') . '">' . $zone->domainstatus . '</span></td><td><a href="clientsservices.php?id=' . $zone->id . '" class="btn btn-xs btn-primary">Manage</a></td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<div class="alert alert-info">No active CDN zones found.</div>';
    }
    echo '</div></div>';
}

function showBillingHistory()
{
    $billingRecords = Capsule::table('mod_seekahostcdn_billing')
        ->join('tblhosting', 'mod_seekahostcdn_billing.service_id', '=', 'tblhosting.id')
        ->join('tblclients', 'tblhosting.userid', '=', 'tblclients.id')
        ->select('mod_seekahostcdn_billing.*', 'tblhosting.domain', 'tblhosting.userid', 'tblclients.firstname', 'tblclients.lastname')
        ->orderBy('mod_seekahostcdn_billing.created_at', 'DESC')
        ->limit(50)
        ->get();
    
    echo '<div class="panel panel-default"><div class="panel-heading"><h4>Billing History</h4></div><div class="panel-body">';
    if (count($billingRecords) > 0) {
        echo '<table class="table table-striped"><thead><tr><th>Client</th><th>Domain</th><th>Month</th><th>Bandwidth</th><th>Cost</th><th>Invoice</th></tr></thead><tbody>';
        foreach ($billingRecords as $bill) {
            echo '<tr><td><a href="clientssummary.php?userid=' . $bill->userid . '">' . htmlspecialchars($bill->firstname . ' ' . $bill->lastname) . '</a></td><td>' . htmlspecialchars($bill->domain) . '</td><td>' . $bill->billing_month . '</td><td>' . $bill->bandwidth_gb . ' GB</td><td>$' . number_format($bill->cost, 2) . '</td><td><a href="invoices.php?action=edit&id=' . $bill->invoice_id . '">#' . $bill->invoice_id . '</a></td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="text-muted">No billing records yet.</p>';
    }
    echo '</div></div>';
}

function showSettingsForm()
{
    $settings = getModuleSettings();
    
    echo '<div class="panel panel-default"><div class="panel-heading"><h4>SeekaHost CDN Settings</h4></div><div class="panel-body">';
    echo '<form method="post" class="form-horizontal"><input type="hidden" name="save_settings" value="1">';
    
    echo '<div class="form-group"><label class="col-sm-3 control-label">API Endpoint URL</label><div class="col-sm-9"><input type="url" name="api_url" class="form-control" value="' . htmlspecialchars($settings['api_url'] ?? '') . '" placeholder="https://api.yourcdn.com/v1"><span class="help-block">The base URL for your CDN API</span></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">API Key</label><div class="col-sm-9"><input type="password" name="api_key" class="form-control" value="' . htmlspecialchars($settings['api_key'] ?? '') . '" placeholder="Enter your API key"><span class="help-block">Your secret API key for authentication</span></div></div>';
    echo '<hr>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Price per GB</label><div class="col-sm-9"><div class="input-group"><span class="input-group-addon">$</span><input type="number" name="price_per_gb" class="form-control" step="0.01" min="0" value="' . htmlspecialchars($settings['price_per_gb'] ?? '0.05') . '"><span class="input-group-addon">per GB</span></div><span class="help-block">Amount to charge clients per GB of bandwidth</span></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Billing Cycle</label><div class="col-sm-9"><select name="billing_cycle" class="form-control"><option value="daily"' . (($settings['billing_cycle'] ?? '') == 'daily' ? ' selected' : '') . '>Daily</option><option value="weekly"' . (($settings['billing_cycle'] ?? '') == 'weekly' ? ' selected' : '') . '>Weekly</option><option value="monthly"' . (($settings['billing_cycle'] ?? '') == 'monthly' ? ' selected' : '') . '>Monthly</option></select><span class="help-block">How often to generate bandwidth invoices</span></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Default Bandwidth Limit</label><div class="col-sm-9"><div class="input-group"><input type="number" name="default_bandwidth_limit" class="form-control" min="0" value="' . htmlspecialchars($settings['default_bandwidth_limit'] ?? '1000') . '"><span class="input-group-addon">GB</span></div><span class="help-block">Default monthly bandwidth limit for new zones (0 = unlimited)</span></div></div>';
    echo '<hr><h4>Usage-Based Billing</h4>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Enable Usage Billing</label><div class="col-sm-9"><label class="checkbox-inline"><input type="checkbox" name="enable_billing" value="1"' . (($settings['enable_billing'] ?? '') ? ' checked' : '') . '> Automatically bill clients for bandwidth usage</label></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Billing Day</label><div class="col-sm-9"><select name="billing_day" class="form-control" style="max-width:200px;">';
    for ($i = 1; $i <= 28; $i++) {
        echo '<option value="' . $i . '"' . (($settings['billing_day'] ?? '1') == $i ? ' selected' : '') . '>' . $i . '</option>';
    }
    echo '</select><span class="help-block">Day of month to generate usage invoices</span></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Minimum Invoice</label><div class="col-sm-9"><div class="input-group"><span class="input-group-addon">$</span><input type="number" name="min_invoice" class="form-control" step="0.01" min="0" value="' . htmlspecialchars($settings['min_invoice'] ?? '0.50') . '"></div><span class="help-block">Skip invoices below this amount</span></div></div>';
    echo '<hr>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">Auto-Suspend</label><div class="col-sm-9"><label class="checkbox-inline"><input type="checkbox" name="auto_suspend" value="1"' . (($settings['auto_suspend'] ?? '') ? ' checked' : '') . '> Automatically suspend zones when bandwidth limit is exceeded</label></div></div>';
    echo '<div class="form-group"><label class="col-sm-3 control-label">License Key</label><div class="col-sm-9"><input type="text" name="license_key" class="form-control" value="' . htmlspecialchars($settings['license_key'] ?? '') . '" placeholder="Enter your license key"><span class="help-block">Required for automatic updates and support</span></div></div>';
    echo '<div class="form-group"><div class="col-sm-offset-3 col-sm-9"><button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Settings</button></div></div>';
    echo '</form></div></div>';
}

function showHelpPage()
{
    echo '<div class="panel panel-default"><div class="panel-heading"><h4>SeekaHost CDN Help</h4></div><div class="panel-body">';
    echo '<h4>Quick Setup Guide</h4><ol><li>Configure API settings in Settings tab</li><li>Create a product in WHMCS (Setup → Products/Services)</li><li>Select "SeekaHost CDN" as the module type</li><li>Clients can now order CDN services</li></ol>';
    echo '<h4>Support</h4><p>For assistance, contact us at <a href="mailto:support@seekahost.com">support@seekahost.com</a></p>';
    echo '<p><strong>Module Version:</strong> 1.0.0</p>';
    echo '</div></div>';
}

function saveSettings($data)
{
    $settings = [
        'api_url' => $data['api_url'] ?? '',
        'api_key' => $data['api_key'] ?? '',
        'price_per_gb' => $data['price_per_gb'] ?? '0.05',
        'billing_cycle' => $data['billing_cycle'] ?? 'monthly',
        'default_bandwidth_limit' => $data['default_bandwidth_limit'] ?? '1000',
        'auto_suspend' => isset($data['auto_suspend']) ? '1' : '0',
        'license_key' => $data['license_key'] ?? '',
        'enable_billing' => isset($data['enable_billing']) ? '1' : '0',
        'billing_day' => $data['billing_day'] ?? '1',
        'min_invoice' => $data['min_invoice'] ?? '0.50',
    ];
    foreach ($settings as $key => $value) {
        Capsule::table('tbladdonmodules')->updateOrInsert(['module' => 'seekahostcdn', 'setting' => $key], ['value' => $value]);
    }
}

function getModuleSettings()
{
    $defaults = ['api_url' => '', 'api_key' => '', 'price_per_gb' => '0.05', 'billing_cycle' => 'monthly', 'default_bandwidth_limit' => '1000', 'auto_suspend' => '0', 'license_key' => '', 'enable_billing' => '0', 'billing_day' => '1', 'min_invoice' => '0.50'];
    $stored = Capsule::table('tbladdonmodules')->where('module', 'seekahostcdn')->pluck('value', 'setting')->toArray();
    return array_merge($defaults, $stored);
}

// =============================================
// HELPER FUNCTIONS
// =============================================

function getAllActiveZones()
{
    return Capsule::table('tblhosting')
        ->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')
        ->join('tblclients', 'tblhosting.userid', '=', 'tblclients.id')
        ->where('tblhosting.domainstatus', 'Active')
        ->where('tblproducts.servertype', 'seekahostcdn')
        ->whereNotNull('tblhosting.dedicatedip')
        ->select('tblhosting.id', 'tblhosting.userid', 'tblhosting.domain', 'tblhosting.dedicatedip', 'tblhosting.domainstatus', 'tblhosting.created_at', 'tblclients.firstname', 'tblclients.lastname')
        ->orderBy('tblhosting.created_at', 'DESC')
        ->get();
}

function getActiveZonesCount()
{
    return Capsule::table('tblhosting')->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')->where('tblhosting.domainstatus', 'Active')->where('tblproducts.servertype', 'seekahostcdn')->count();
}

function getMonthlyBandwidthTotal()
{
    $debugLog = __DIR__ . '/admin_debug.log';
    file_put_contents($debugLog, date('Y-m-d H:i:s') . " === getMonthlyBandwidthTotal ===\n", FILE_APPEND);
    
    $totalBytes = 0;
    $zones = Capsule::table('mod_seekahostcdn_dns_zones')
        ->join('tblhosting', 'mod_seekahostcdn_dns_zones.service_id', '=', 'tblhosting.id')
        ->where('tblhosting.domainstatus', 'Active')
        ->select('mod_seekahostcdn_dns_zones.pull_zone_id')
        ->get();
    
    file_put_contents($debugLog, "  Zones found: " . count($zones) . "\n", FILE_APPEND);
    
    $serverData = Capsule::table('tblservers')->where('type', 'seekahostcdn')->first();
    
    if ($serverData && !empty($serverData->accesshash) && $zones->isNotEmpty()) {
        file_put_contents($debugLog, "  Server: {$serverData->name}, AccessHash length: " . strlen($serverData->accesshash) . "\n", FILE_APPEND);
        require_once __DIR__ . '/../../servers/seekahostcdn/lib/BunnyCDN.php';
        $bunny = new BunnyCDN_API($serverData->accesshash);
        foreach ($zones as $zone) {
            if (!empty($zone->pull_zone_id)) {
                $result = $bunny->getMonthlyBandwidth($zone->pull_zone_id);
                file_put_contents($debugLog, "  Zone {$zone->pull_zone_id}: " . json_encode($result) . "\n", FILE_APPEND);
                if ($result['success']) { $totalBytes += $result['total_bytes']; }
            }
        }
    } else {
        file_put_contents($debugLog, "  No server or API key found\n", FILE_APPEND);
    }
    
    file_put_contents($debugLog, "  Total: {$totalBytes} bytes\n", FILE_APPEND);
    return $totalBytes;
}

function getTotalBilledThisMonth()
{
    return Capsule::table('mod_seekahostcdn_billing')->where('billing_month', date('Y-m'))->sum('cost') ?: 0;
}

function formatBytes($bytes, $precision = 2)
{
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
}

function getZoneBandwidthThisMonth($serviceId)
{
    $debugLog = __DIR__ . '/admin_debug.log';
    file_put_contents($debugLog, date('Y-m-d H:i:s') . " === getZoneBandwidthThisMonth - Service {$serviceId} ===\n", FILE_APPEND);
    
    $dnsInfo = Capsule::table('mod_seekahostcdn_dns_zones')->where('service_id', $serviceId)->first();
    
    if (!$dnsInfo) {
        file_put_contents($debugLog, "  No DNS info found for service {$serviceId}\n", FILE_APPEND);
        return 0;
    }
    
    file_put_contents($debugLog, "  Pull Zone ID: {$dnsInfo->pull_zone_id}\n", FILE_APPEND);
    
    if ($dnsInfo && !empty($dnsInfo->pull_zone_id)) {
        $serverData = Capsule::table('tblservers')->where('type', 'seekahostcdn')->first();
        
        if (!$serverData) {
            file_put_contents($debugLog, "  No server found\n", FILE_APPEND);
            return 0;
        }
        
        file_put_contents($debugLog, "  Server: {$serverData->name}, AccessHash length: " . strlen($serverData->accesshash ?? '') . "\n", FILE_APPEND);
        
        if ($serverData && !empty($serverData->accesshash)) {
            require_once __DIR__ . '/../../servers/seekahostcdn/lib/BunnyCDN.php';
            $bunny = new BunnyCDN_API($serverData->accesshash);
            $result = $bunny->getMonthlyBandwidth($dnsInfo->pull_zone_id);
            
            file_put_contents($debugLog, "  API Result: " . json_encode($result) . "\n", FILE_APPEND);
            
            if ($result['success']) { 
                file_put_contents($debugLog, "  SUCCESS: {$result['total_bytes']} bytes\n", FILE_APPEND);
                return $result['total_bytes']; 
            }
        } else {
            file_put_contents($debugLog, "  No AccessHash\n", FILE_APPEND);
        }
    }
    
    file_put_contents($debugLog, "  Falling back to DB\n", FILE_APPEND);
    $monthStart = date('Y-m-01');
    return Capsule::table('mod_seekahostcdn_usage')->where('service_id', $serviceId)->where('usage_date', '>=', $monthStart)->sum('bandwidth_bytes') ?: 0;
}

function getTotalCDNClients()
{
    return Capsule::table('tblhosting')->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')->where('tblhosting.domainstatus', 'Active')->where('tblproducts.servertype', 'seekahostcdn')->distinct('userid')->count('userid');
}

function getRecentZones($limit = 5)
{
    return Capsule::table('tblhosting')->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')->join('tblclients', 'tblhosting.userid', '=', 'tblclients.id')->where('tblproducts.servertype', 'seekahostcdn')->whereIn('tblhosting.domainstatus', ['Active', 'Pending'])->select('tblhosting.id', 'tblhosting.userid', 'tblhosting.domain', 'tblhosting.dedicatedip', 'tblhosting.domainstatus', 'tblhosting.created_at', 'tblclients.firstname', 'tblclients.lastname')->orderBy('tblhosting.created_at', 'DESC')->limit($limit)->get();
}

// =============================================
// HOOKS FOR AUTOMATION
// =============================================

add_hook('DailyCronJob', 1, function($vars) {
    $settings = getModuleSettings();
    if (empty($settings['enable_billing'])) { return; }
    $billingDay = intval($settings['billing_day'] ?? '1');
    if (date('d') != $billingDay) { return; }
    generateUsageInvoices($settings);
});

function generateUsageInvoices($settings) {
    $debugLog = __DIR__ . '/admin_debug.log';
    file_put_contents($debugLog, date('Y-m-d H:i:s') . " === generateUsageInvoices ===\n", FILE_APPEND);
    
    $pricePerGB = floatval($settings['price_per_gb'] ?? 0.05);
    $minInvoice = floatval($settings['min_invoice'] ?? 0.50);
    $serverData = Capsule::table('tblservers')->where('type', 'seekahostcdn')->first();
    if (!$serverData || empty($serverData->accesshash)) { 
        file_put_contents($debugLog, "  No server or API key\n", FILE_APPEND);
        logActivity('SeekaHost CDN Billing: API key not configured'); return; 
    }
    $services = Capsule::table('tblhosting')->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')->join('mod_seekahostcdn_dns_zones', 'tblhosting.id', '=', 'mod_seekahostcdn_dns_zones.service_id')->where('tblhosting.domainstatus', 'Active')->where('tblproducts.servertype', 'seekahostcdn')->select('tblhosting.id', 'tblhosting.userid', 'mod_seekahostcdn_dns_zones.pull_zone_id')->get();
    if ($services->isEmpty()) { file_put_contents($debugLog, "  No active services\n", FILE_APPEND); logActivity('SeekaHost CDN Billing: No active services found'); return; }
    require_once __DIR__ . '/../../servers/seekahostcdn/lib/BunnyCDN.php';
    $bunny = new BunnyCDN_API($serverData->accesshash);
    $invoicedCount = 0;
    foreach ($services as $service) {
        $bandwidthResult = $bunny->getMonthlyBandwidth($service->pull_zone_id);
        file_put_contents($debugLog, "  Service {$service->id}, Zone {$service->pull_zone_id}: " . json_encode($bandwidthResult) . "\n", FILE_APPEND);
        if (!$bandwidthResult['success']) { continue; }
        $totalGB = $bandwidthResult['total_gb'];
        $cost = round($totalGB * $pricePerGB, 2);
        if ($cost < $minInvoice) { continue; }
        $existing = Capsule::table('mod_seekahostcdn_billing')->where('service_id', $service->id)->where('billing_month', date('Y-m'))->first();
        if ($existing) { continue; }
        $invoiceResult = localAPI('CreateInvoice', ['userid' => $service->userid, 'status' => 'Unpaid', 'date' => date('Y-m-d'), 'duedate' => date('Y-m-d', strtotime('+7 days')), 'itemdescription1' => 'SeekaHost CDN - Bandwidth Usage (' . date('F Y') . ')', 'itemamount1' => $cost, 'itemtaxed1' => 0]);
        if ($invoiceResult['result'] == 'success') {
            Capsule::table('mod_seekahostcdn_billing')->insert(['service_id' => $service->id, 'billing_month' => date('Y-m'), 'bandwidth_gb' => $totalGB, 'cost' => $cost, 'invoice_id' => $invoiceResult['invoiceid'], 'created_at' => date('Y-m-d H:i:s')]);
            $invoicedCount++;
            logActivity("SeekaHost CDN: Invoiced \${$cost} for service {$service->id} ({$totalGB} GB)");
        }
    }
    file_put_contents($debugLog, "  Invoiced: {$invoicedCount}\n", FILE_APPEND);
    logActivity("SeekaHost CDN Billing: Generated {$invoicedCount} invoices");
}