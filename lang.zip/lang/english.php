<?php

$_ADDONLANG['intro'] = 'This module fully integrates SeekaHost CDN into WHMCS.';
$_ADDONLANG['description'] = 'Automated provisioning of pull zones, usage tracking, bandwidth billing, and client management.';
$_ADDONLANG['settings_saved'] = 'Settings saved successfully!';
$_ADDONLANG['api_error'] = 'Failed to connect to SeekaHost API. Please check your API key.';
$_ADDONLANG['zone_created'] = 'CDN Zone created successfully';
$_ADDONLANG['zone_deleted'] = 'CDN Zone deleted successfully';
$_ADDONLANG['cache_purged'] = 'Cache purged successfully';
$_ADDONLANG['bandwidth_usage'] = 'Bandwidth Usage';
$_ADDONLANG['total_zones'] = 'Total Active Zones';
$_ADDONLANG['monthly_bandwidth'] = 'Monthly Bandwidth';